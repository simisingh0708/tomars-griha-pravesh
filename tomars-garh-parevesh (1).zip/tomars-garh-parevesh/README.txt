Tomar's Griha Pravesh - Invitation Website
==========================================

OPEN LOCALLY
Keep index.html and ghar-me-padharo-gajanan-ji.mp3 in the same folder, then double-click index.html.
(Internet is only used for Google Fonts.)

EDIT DETAILS
Open index.html in a text editor and change the CONFIG block near the bottom:
  family, whatsapp, venue, paath (date/duration/start time), lunch,
  ganeshImg (your Ganapati Bappa photograph, e.g. "ganesh.jpg"),
  homePhoto, musicSrc, blessings (portraits).
Put any photos in the same folder as index.html. The Ramayan Paath start time reads "[To be updated]".

MUSIC
The song tries to start as soon as the page opens; browsers often block this, so it starts on the visitor first tap or key press (or ENTER INVITATION); the music button (top right) pauses/plays it.
Please make sure you have the right to use the song on your invitation.

FREE HOSTING (GitHub Pages)
1. Create a free GitHub account and a new public repository.
2. Upload everything in this folder (index.html, the mp3 and any photos).
3. Settings > Pages > Deploy from a branch > main / (root) > Save.
4. Your site goes live at https://<username>.github.io/<repository>/
Other free options: Netlify Drop (drag the folder onto app.netlify.com/drop), Cloudflare Pages.
